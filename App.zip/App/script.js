// بيانات التطبيق المحسنة
const appData = {
  loadingMessages: {
    scan: [
      "🔍 جاري تحليل بصمتك...",
      "🤖 نفحص بياناتك الجينية...",
      "🧬 نكتشف أسرار شخصيتك..."
    ],
    death: [
      "☠️ نقرأ كفك الأخير...",
      "⏳ نستشرف مستقبلك...",
      "💀 نبحث عن نهايتك المحتومة..."
    ]
  },
  scanResults: [
    { text: "🧠 تحليلنا يظهر أنك تمتلك عقلية عبقرة بنسبة 98%!", emoji: "🌟" },
    { text: "👽 لديك 87% من صفات الكائنات الفضائية... هل أنت منهم؟", emoji: "🛸" },
    { text: "🎯 تركيزك يشبه الليزر عندما يتعلق الأمر بالطعام!", emoji: "🍔" },
    { text: "😂 لديك موهبة فطرية في إضحاك الآخرين دون أن تحاول!", emoji: "🤡" },
    { text: "🦸‍♂️ لديك قوى خارقة لكنك تفضل الكسل على استخدامها!", emoji: "🛌" },
    { text: "🧙‍♂️ لو كنت في هاري بوتر لكنت ساحراً من منزل 'المبهمين'!", emoji: "⚡" },
    { text: "🐢 سرعتك في إنجاز المهام تشبه السلحفاة... لكنك دائماً تصل!", emoji: "🐢" },
    { text: "🎮 لو كانت الحياة لعبة لكنت قد اخترت مستوى 'صعب جداً'!", emoji: "🎮" },
    { text: "🍔 95% من أفكارك تدور حول الطعام... و5% حول متى تأكل!", emoji: "🍕" },
    { text: "🤴 لديك شخصية ملكية... ملك الكسل والاسترخاء!", emoji: "👑" },
    { text: "🧐 لديك قدرة خارقة على اكتشاف الأخطاء الإملائية من مسافة 10 أمتار!", emoji: "🔍" },
    { text: "🕵️‍♂️ مهاراتك في البحث عن الأعذار تفوق مهارة المحققين المحترفين!", emoji: "🙈" }
  ],
  deathResults: [
    { text: "💀 ستلقى حتفك من الضحك على ميم قديم وجدته بالصدفة!", emoji: "😂" },
    { text: "🍕 نهايتك ستكون بسبب تناولك لشطيرة بحجمك مرتين!", emoji: "🍔" },
    { text: "📱 ستسقط هاتفك على وجهك أثناء تصفحك للميمز ليلاً!", emoji: "😵" },
    { text: "🛌 ستغرق في نوم عميق جداً لدرجة أنك لن تستيقظ!", emoji: "😴" },
    { text: "🎮 ستخسر في لعبة سهلة وتفارق الحياة من شدة الغضب!", emoji: "👾" },
    { text: "🚽 ستقضي نحبك وأنت تحاول فهم نكتة قديمة!", emoji: "🤔" },
    { text: "🍫 ستتناول الكثير من الشوكولاتة لدرجة أنك ستنفجر!", emoji: "🍫" },
    { text: "🤯 رأسك سينفجر من كثرة التفكير في معنى الحياة!", emoji: "💥" },
    { text: "👻 ستخاف من ظلك بنفسك وتفارق الحياة من شدة الخوف!", emoji: "👻" },
    { text: "🤦‍♂️ ستنسى أن تتنفس لأنك منشغل جداً بهاتفك!", emoji: "📵" },
    { text: "🍌 ستنزلق على قشرة موز بطريقة درامية جداً!", emoji: "🍌" },
    { text: "🦖 سيتم استنساخ الديناصورات وستكون أول ضحية لهم!", emoji: "🦖" }
  ]
};

// متغيرات التحكم
let isScanning = false;
let isPredictingDeath = false;

// تأثيرات
function triggerConfetti() {
  confetti({
    particleCount: 100,
    spread: 70,
    origin: { y: 0.6 }
  });
}

function triggerRIPEffect() {
  document.body.classList.add('death-flash');
  setTimeout(() => {
    document.body.classList.remove('death-flash');
  }, 1000);
}

// الوظائف الرئيسية
function startScan() {
  if (isScanning) return;
  
  isScanning = true;
  const result = document.getElementById('result');
  const loadingMessage = appData.loadingMessages.scan[
    Math.floor(Math.random() * appData.loadingMessages.scan.length)
  ];
  
  result.innerHTML = `
    <div class="loading">
      <span class="message">${loadingMessage}</span>
      <span class="spinner">🌀</span>
    </div>
  `;
  result.classList.add('animate__fadeIn');
  
  setTimeout(() => {
    const randomResult = appData.scanResults[
      Math.floor(Math.random() * appData.scanResults.length)
    ];
    result.innerHTML = `
      <div class="result-content">
        <span class="emoji">${randomResult.emoji}</span>
        <span class="text">${randomResult.text}</span>
      </div>
    `;
    result.classList.add('animate__heartBeat');
    isScanning = false;
    triggerConfetti();
    
    setTimeout(() => {
      result.classList.remove('animate__heartBeat');
    }, 1000);
  }, 2000 + Math.random() * 2000);
}

function showDeath() {
  if (isPredictingDeath) return;
  
  isPredictingDeath = true;
  const deathResult = document.getElementById('deathResult');
  const loadingMessage = appData.loadingMessages.death[
    Math.floor(Math.random() * appData.loadingMessages.death.length)
  ];
  
  deathResult.innerHTML = `
    <div class="loading">
      <span class="message">${loadingMessage}</span>
      <span class="spinner">💀</span>
    </div>
  `;
  deathResult.classList.add('animate__fadeIn');
  
  setTimeout(() => {
    const randomResult = appData.deathResults[
      Math.floor(Math.random() * appData.deathResults.length)
    ];
    deathResult.innerHTML = `
      <div class="result-content">
        <span class="emoji">${randomResult.emoji}</span>
        <span class="text">${randomResult.text}</span>
      </div>
    `;
    deathResult.classList.add('animate__shakeX');
    isPredictingDeath = false;
    triggerRIPEffect();
    
    setTimeout(() => {
      deathResult.classList.remove('animate__shakeX');
    }, 1000);
  }, 3000 + Math.random() * 3000);
}

// تهيئة التطبيق
document.addEventListener('DOMContentLoaded', () => {
  console.log('التطبيق جاهز للعمل!');
  
  // إضافة تأثيرات للعناصر عند التحميل
  setTimeout(() => {
    document.querySelector('.header').classList.add('animate__fadeInDown');
    document.querySelector('.scanner').classList.add('animate__zoomIn');
    document.querySelector('.footer').classList.add('animate__fadeInUp');
  }, 500);
});